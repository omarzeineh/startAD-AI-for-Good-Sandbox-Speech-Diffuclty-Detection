// postcss.config.js (Tailwind v3)
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
