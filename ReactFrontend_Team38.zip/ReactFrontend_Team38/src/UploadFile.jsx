// src/UploadFile.jsx
import React, { useState, useRef, useCallback } from "react";
import {
  Mic,
  Sparkles,
  Upload as UploadIcon,
  FileAudio,
  Loader2,
  XCircle,
  Trash2,
  CheckCircle2,
} from "lucide-react";

export default function UploadFile() {
  const [files, setFiles] = useState([]);
  const [busy, setBusy] = useState(false);
  const [results, setResults] = useState([]); // [{name, sizeMB, status, prediction?, score?, error?}]
  const [msg, setMsg] = useState("");
  const inputRef = useRef(null);
  const [isDragOver, setIsDragOver] = useState(false);

  const addFiles = useCallback((fileList) => {
    const next = [];
    for (const f of fileList) {
      // accept only .wav
      if (!f.name.toLowerCase().endsWith(".wav")) continue;
      next.push(f);
    }
    if (next.length === 0) {
      setMsg("Please add .wav files only.");
      return;
    }
    setMsg("");
    setFiles((prev) => {
      const key = (f) => `${f.name}:${f.size}`;
      const seen = new Set(prev.map(key));
      const merged = [...prev];
      for (const f of next) {
        if (!seen.has(key(f))) {
          merged.push(f);
          seen.add(key(f));
        }
      }
      return merged;
    });
  }, []);

  const onInputChange = (e) => addFiles(e.target.files || []);
  const onDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
    addFiles(e.dataTransfer?.files || []);
  };
  const onDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(true);
  };
  const onDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
  };

  const removeFile = (idx) => {
    setFiles((prev) => prev.filter((_, i) => i !== idx));
    setResults((prev) => prev.filter((_, i) => i !== idx));
  };

  // Single-file endpoint
  const analyzeOne = async (file) => {
    const formData = new FormData();
    formData.append("file", file);
    const res = await fetch("http://127.0.0.1:5000/predict", {
      method: "POST",
      body: formData,
    });
    const data = await res.json();
    if (!res.ok || data.ok === false) {
      throw new Error(data.error || "Request failed");
    }
    return { prediction: data.prediction, score: data.score };
  };

  // Prefer batch endpoint; fallback to single if 404
  const analyzeBatch = async (fileList) => {
    const formData = new FormData();
    for (const f of fileList) formData.append("files", f);
    const res = await fetch("http://127.0.0.1:5000/predict-batch", {
      method: "POST",
      body: formData,
    });

    if (res.status === 404) {
      const outputs = [];
      for (const f of fileList) {
        const r = await analyzeOne(f);
        outputs.push({ name: f.name, prediction: r.prediction, score: r.score });
      }
      return { ok: true, results: outputs };
    }

    const data = await res.json();
    if (!res.ok || data.ok === false) {
      throw new Error(data.error || "Batch request failed");
    }
    return data; // {ok:true, results:[{name,prediction,score}|{name,error}]}
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (files.length === 0) {
      setMsg("Please add at least one .wav file.");
      return;
    }

    // Seed pending rows
    setResults(
      files.map((f) => ({
        name: f.name,
        sizeMB: (f.size / 1024 / 1024).toFixed(2),
        status: "pending",
      }))
    );

    setBusy(true);
    setMsg("");
    try {
      const data = await analyzeBatch(files);
      const mapped = files.map((f) => {
        const r = data.results.find((x) => x.name === f.name);
        if (!r)
          return {
            name: f.name,
            sizeMB: (f.size / 1024 / 1024).toFixed(2),
            status: "error",
            error: "Missing in server response",
          };
        if (r.error)
          return {
            name: f.name,
            sizeMB: (f.size / 1024 / 1024).toFixed(2),
            status: "error",
            error: r.error,
          };
        return {
          name: f.name,
          sizeMB: (f.size / 1024 / 1024).toFixed(2),
          status: "ok",
          prediction: r.prediction,
          score: r.score,
        };
      });
      setResults(mapped);
    } catch (err) {
      setMsg(`Error: ${String(err.message || err)}`);
      setResults((prev) =>
        prev.map((r) => ({
          ...r,
          status: r.status === "pending" ? "error" : r.status,
          error: r.error || "Failed request",
        }))
      );
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex flex-col">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-6 py-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-br from-blue-500 to-purple-600 p-2.5 rounded-xl shadow-lg">
                <Mic className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  Speech Analysis Platform
                </h1>
                <p className="text-sm text-gray-600">
                  AI-powered speech disorder detection
                </p>
              </div>
            </div>
            <div className="hidden md:flex items-center space-x-2 text-gray-600">
              <Sparkles className="h-4 w-4" />
              <span className="text-sm font-medium">AI Powered</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-6 py-10">
        <div className="border border-gray-200 rounded-2xl bg-white shadow-sm hover:shadow-md transition-shadow">
          <div className="px-6 pt-6">
            <h2 className="text-xl font-semibold text-gray-900 flex items-center space-x-2">
              <UploadIcon className="h-5 w-5 text-blue-500" />
              <span>Upload .WAV Files</span>
            </h2>
            <p className="text-sm text-gray-500 mt-1">
              Add multiple audio files (.wav) via click or drag & drop.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="p-6 space-y-6">
            {/* Dropzone */}
            <div
              onDrop={onDrop}
              onDragOver={onDragOver}
              onDragLeave={onDragLeave}
              className={`border-2 border-dashed rounded-xl p-10 text-center transition cursor-pointer ${
                isDragOver
                  ? "border-blue-400 bg-blue-50"
                  : "border-gray-300 hover:border-gray-400 hover:bg-gray-50"
              }`}
              onClick={() => inputRef.current?.click()}
            >
              <input
                ref={inputRef}
                type="file"
                accept=".wav,audio/wav"
                className="hidden"
                multiple
                onChange={onInputChange}
              />
              <div className="flex flex-col items-center">
                <UploadIcon className="h-12 w-12 text-gray-400 mb-3" />
                <span className="text-gray-700 font-medium">
                  Click to choose files or drag them here
                </span>
                <span className="text-gray-500 text-sm">
                  .WAV only • You can add more before analyzing
                </span>
              </div>
            </div>

            {/* Selected files list */}
            {files.length > 0 && (
              <div className="space-y-2">
                {files.map((f, idx) => (
                  <div
                    key={`${f.name}-${f.size}-${idx}`}
                    className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-200"
                  >
                    <div className="flex items-center space-x-3">
                      <FileAudio className="h-5 w-5 text-blue-500" />
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          {f.name}
                        </p>
                        <p className="text-xs text-gray-500">
                          {(f.size / 1024 / 1024).toFixed(2)} MB
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => removeFile(idx)}
                      className="text-gray-400 hover:text-red-500 transition-colors"
                      aria-label={`Remove ${f.name}`}
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Analyze */}
            <button
              type="submit"
              disabled={busy || files.length === 0}
              className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white font-medium py-3 rounded-lg shadow-lg hover:shadow-xl hover:scale-[1.01] transition disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center"
            >
              {busy ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Analyzing {files.length} file{files.length > 1 ? "s" : ""}...
                </>
              ) : (
                <>
                  <UploadIcon className="w-5 h-5 mr-2" />
                  Analyze {files.length > 0 ? `(${files.length})` : ""}
                </>
              )}
            </button>

            {/* Message box */}
            {msg && (
              <div className="mt-2 bg-gray-50 border border-gray-200 rounded-lg p-4 text-sm text-gray-800">
                {msg}
              </div>
            )}

            {/* Results */}
            {results.length > 0 && (
              <div className="mt-4 space-y-2">
                {results.map((r, i) => (
                  <div
                    key={`${r.name}-${i}`}
                    className="flex items-center justify-between p-4 bg-white rounded-lg border"
                  >
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-gray-900 truncate">
                        {r.name}
                      </p>
                      <p className="text-xs text-gray-500">{r.sizeMB} MB</p>
                    </div>
                    <div className="ml-4">
                      {r.status === "pending" && (
                        <span className="inline-flex items-center text-sm text-gray-600">
                          <Loader2 className="w-4 h-4 mr-1 animate-spin" /> Processing
                        </span>
                      )}
                      {r.status === "ok" && (
                        <span
                          className={`inline-flex items-center text-sm ${
                            r.prediction?.toLowerCase() === "normal"
                              ? "text-green-600"
                              : "text-red-600"
                          }`}
                        >
                          <CheckCircle2 className="w-4 h-4 mr-1" />
                          Prediction: {r.prediction}
                          {r.score !== undefined && (
                            <span className="ml-1 text-gray-700">
                              ({Number(r.score).toFixed(2)}%)
                            </span>
                          )}
                        </span>
                      )}
                      {r.status === "error" && (
                        <span className="inline-flex items-center text-sm text-red-600">
                          <XCircle className="w-4 h-4 mr-1" /> Error:{" "}
                          {r.error || "Failed"}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </form>
        </div>

        {/* Footer tile */}
        <div className="mt-12 flex justify-center">
          <div className="text-center p-8 bg-white rounded-xl border border-gray-200 shadow-sm">
            <div className="bg-purple-100 rounded-full p-4 w-fit mx-auto mb-4">
              <Mic className="h-8 w-8 text-purple-600" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-3 text-lg">
              Consistent, fast, and friendly UI
            </h3>
            <p className="text-sm text-gray-600 leading-relaxed">
              Designed to match your main page style with minimal changes to your existing code.
            </p>
          </div>
        </div>
      </main>

      {/* Site footer */}
      <footer className="border-t bg-white/80 backdrop-blur-md mt-12">
        <div className="max-w-6xl mx-auto px-6 py-6 text-center text-sm text-gray-600">
          © 2025 Speech Analysis Platform
        </div>
      </footer>
    </div>
  );
}
