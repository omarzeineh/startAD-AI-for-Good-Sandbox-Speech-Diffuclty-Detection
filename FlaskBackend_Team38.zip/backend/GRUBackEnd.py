# GRUBackEnd.py — BiGRU inference backend (drop-in replacement)

from flask import Flask, request, jsonify
from flask_cors import CORS
import torch, torchaudio, tempfile, os
from pathlib import Path

from train_gru_dysarthria import DysarthriaGRU 

app = Flask(__name__)
CORS(app, resources={
    r"/*": {
        "origins": [
            "http://localhost:3000",
            "http://127.0.0.1:3000",
            "http://localhost:5173",
            "http://127.0.0.1:5173",
        ]
    }
})

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

CKPT_PATH = "best_gru.pt" 

model = DysarthriaGRU().to(DEVICE)
state = torch.load(CKPT_PATH, map_location=DEVICE)
model.load_state_dict(state)
model.eval()

TARGET_SR = 44100

def load_wav_mono_resample(path, target_sr=TARGET_SR):
    wav, sr = torchaudio.load(path)
    if wav.shape[0] > 1:
        wav = wav.mean(dim=0, keepdim=True)
    if sr != target_sr:
        wav = torchaudio.transforms.Resample(sr, target_sr)(wav)
    return wav.squeeze(0) 

IDX_TO_LABEL = ["Normal", "Dysarthria"]

def predict_one_tensor(wav_1d: torch.Tensor):
    """
    wav_1d: (T,) on CPU or GPU
    Returns: (label_str, score_percent_float)
    """
    if wav_1d.ndim != 1:
        raise ValueError("Expected 1-D waveform")
    wav = wav_1d.unsqueeze(0).unsqueeze(0).to(DEVICE)
    lengths = torch.tensor([wav.shape[-1]], device=DEVICE)
    with torch.no_grad():
        probs = model.predict(wav, lengths)
        probs = probs.squeeze(0).detach().cpu().numpy()
        pred_idx = int(probs.argmax())
        pred_label = IDX_TO_LABEL[pred_idx]
        pred_score = round(float(probs[pred_idx]) * 100.0, 2)
    return pred_label, pred_score

# --------- Routes ----------
@app.route('/predict', methods=['POST', 'OPTIONS'])
def predict():
    if request.method == 'OPTIONS':
        return ('', 200)

    if 'file' not in request.files:
        return jsonify({"ok": False, "error": "No file part"}), 400
    f = request.files['file']
    if not f.filename.lower().endswith('.wav'):
        return jsonify({"ok": False, "error": "Only .wav allowed"}), 400

    with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as tmp:
        f.save(tmp.name)
        temp_path = tmp.name

    try:
        w = load_wav_mono_resample(temp_path)  # (T,)
        label, score = predict_one_tensor(w)
        return jsonify({"ok": True, "prediction": label, "score": score}), 200
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500
    finally:
        try:
            os.remove(temp_path)
        except Exception:
            pass

@app.route('/predict-batch', methods=['POST', 'OPTIONS'])
def predict_batch():
    if request.method == 'OPTIONS':
        return ('', 200)

    files = request.files.getlist('files')
    if not files:
        return jsonify({"ok": False, "error": "No files provided (use 'files' form field)."}), 400

    out = []
    for f in files:
        name = f.filename or "unnamed.wav"
        if not name.lower().endswith('.wav'):
            out.append({"name": name, "error": "Only .wav allowed"})
            continue

        temp_path = None
        try:
            with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as tmp:
                f.save(tmp.name)
                temp_path = tmp.name
            w = load_wav_mono_resample(temp_path)
            label, score = predict_one_tensor(w)
            out.append({"name": name, "prediction": label, "score": score})
        except Exception as e:
            out.append({"name": name, "error": str(e)})
        finally:
            if temp_path:
                try:
                    os.remove(temp_path)
                except Exception:
                    pass

    return jsonify({"ok": True, "results": out}), 200

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=True, use_reloader=False)
