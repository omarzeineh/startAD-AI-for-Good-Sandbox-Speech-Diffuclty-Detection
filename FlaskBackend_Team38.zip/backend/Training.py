import os
import math
from typing import List, Tuple

import torch
import torchaudio
from torch import nn
from torch.utils.data import Dataset, DataLoader

# ============================
# EDIT THESE (in-code config)
# ============================
DATA_ROOT   = r"D:\unistuff\2025-2026\Fall2025-2026\cohort\SmallSplit"   # <-- change to your dataset root containing train/ val/ test/
SR          = 44100           # target sample rate
EPOCHS      = 12
BATCH_SIZE  = 8
LR          = 2e-4
NUM_WORKERS = 2
SEED        = 42
SAVE_PATH   = "audio_transformer_best.pth"
INFER_WAV   = None             # e.g., r"./some_example.wav" or keep None to skip inference

# Transformer / patching
D_MODEL     = 128
NHEAD       = 4                # must divide D_MODEL
NUM_LAYERS  = 4
DIM_FF      = 256
DROPOUT     = 0.1
PATCH_SIZE  = 400
PATCH_STRIDE= 200              # 50% overlap

# Class mapping (folder names)
CLASSES     = ["Normal", "Dysarthria"]

# ============================
# Reproducibility & Device
# ============================
torch.manual_seed(SEED)
torch.cuda.manual_seed_all(SEED)
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"


# ============================
# Dataset & Collate
# ============================
class AudioFolderDataset(Dataset):
    """
    Expects:
      split_dir/
        Control/*.wav
        Dys/*.wav
    """
    def __init__(self, split_dir: str, target_sr: int = SR):
        self.items: List[Tuple[str, int]] = []
        self.target_sr = target_sr
        for cls_idx, cls_name in enumerate(CLASSES):
            cls_dir = os.path.join(split_dir, cls_name)
            if not os.path.isdir(cls_dir):
                continue
            for fname in os.listdir(cls_dir):
                if fname.lower().endswith(".wav"):
                    self.items.append((os.path.join(cls_dir, fname), cls_idx))
        self.resamplers = {}

    def _load_wav(self, path: str) -> torch.Tensor:
        wav, sr = torchaudio.load(path)  # (C, T)
        if wav.shape[0] > 1:
            wav = torch.mean(wav, dim=0, keepdim=True)
        if sr != self.target_sr:
            if sr not in self.resamplers:
                self.resamplers[sr] = torchaudio.transforms.Resample(sr, self.target_sr)
            wav = self.resamplers[sr](wav)
        wav = wav.squeeze(0)  # (T,)
        return wav

    def __len__(self):
        return len(self.items)

    def __getitem__(self, idx: int):
        path, label = self.items[idx]
        wav = self._load_wav(path)
        return wav, label, os.path.basename(path)


def collate_batch(batch: List[Tuple[torch.Tensor, int, str]]):
    waves, labels, names = zip(*batch)
    lengths = torch.tensor([w.shape[0] for w in waves], dtype=torch.long)
    T_max = int(lengths.max().item())
    padded = torch.zeros(len(waves), T_max, dtype=torch.float32)
    for i, w in enumerate(waves):
        padded[i, : w.shape[0]] = w
    labels = torch.tensor(labels, dtype=torch.long)
    return padded, lengths, labels, names


# ============================
# Model
# ============================
class PositionalEncoding(nn.Module):
    def __init__(self, d_model: int, max_len: int = 50000):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float32).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2, dtype=torch.float32) * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer("pe", pe.unsqueeze(1))  # (max_len, 1, d_model)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (S, N, E)
        S = x.size(0)
        return x + self.pe[:S]


class AudioTransformerEncoder(nn.Module):
    """
    Raw waveform -> Conv1d patching -> TransformerEncoder
    -> masked mean pool -> feature vector -> FC logits
    """
    def __init__(
        self,
        d_model: int = D_MODEL,
        nhead: int = NHEAD,
        num_layers: int = NUM_LAYERS,
        dim_ff: int = DIM_FF,
        dropout: float = DROPOUT,
        patch_size: int = PATCH_SIZE,
        patch_stride: int = PATCH_STRIDE,
        num_classes: int = 2,
    ):
        super().__init__()
        self.patch = nn.Conv1d(1, d_model, kernel_size=patch_size, stride=patch_stride, bias=False)
        self.pos_enc = PositionalEncoding(d_model)
        enc_layer = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=nhead, dim_feedforward=dim_ff,
            dropout=dropout, activation="gelu", norm_first=True, batch_first=False
        )
        self.encoder = nn.TransformerEncoder(enc_layer, num_layers=num_layers)
        self.norm = nn.LayerNorm(d_model)
        self.classifier = nn.Linear(d_model, num_classes)

        self.patch_size = patch_size
        self.patch_stride = patch_stride
        self.d_model = d_model

    @staticmethod
    def _downsampled_len(orig_len: int, k: int, s: int) -> int:
        if orig_len < k:
            return 0
        return (orig_len - k) // s + 1

    def _make_src_key_padding_mask(self, lengths: torch.LongTensor, max_tokens: int) -> torch.BoolTensor:
        token_lens = []
        for L in lengths.tolist():
            token_lens.append(self._downsampled_len(L, self.patch_size, self.patch_stride))
        token_lens = torch.tensor(token_lens, device=lengths.device)
        mask = torch.ones((lengths.shape[0], max_tokens), dtype=torch.bool, device=lengths.device)
        for i, tlen in enumerate(token_lens.tolist()):
            mask[i, :max(0, tlen)] = False
        return mask

    def forward(self, wave: torch.Tensor, lengths: torch.LongTensor, return_features: bool = False):
        # wave: (B, T)
        x = wave.unsqueeze(1)          # (B, 1, T)
        x = self.patch(x)              # (B, d_model, S)
        if x.shape[-1] == 0:
            # handle very short clips by padding to minimal length
            B, _, T = wave.shape[0], 1, wave.shape[1]
            pad_needed = self.patch_size - T + 1
            xpad = nn.functional.pad(wave, (0, pad_needed)).unsqueeze(1)
            x = self.patch(xpad)

        x = x.permute(2, 0, 1)         # (S, B, d_model)
        x = self.pos_enc(x)
        S = x.shape[0]
        src_key_padding_mask = self._make_src_key_padding_mask(lengths.to(x.device), S)  # (B, S)

        x = self.encoder(x, src_key_padding_mask=src_key_padding_mask)   # (S, B, d)
        x = self.norm(x)

        # masked mean pooling
        mask_valid = (~src_key_padding_mask).float()   # (B, S)
        x_b = x.transpose(0, 1)                        # (B, S, d)
        denom = mask_valid.sum(dim=1, keepdim=True).clamp_min(1.0)
        pooled = (x_b * mask_valid.unsqueeze(-1)).sum(dim=1) / denom     # (B, d)

        logits = self.classifier(pooled)               # (B, 2)
        if return_features:
            return pooled, logits
        return logits


# ============================
# Metrics & Utilities
# ============================
def accuracy_from_logits(logits: torch.Tensor, y: torch.Tensor) -> float:
    preds = logits.argmax(dim=-1)
    return (preds == y).float().mean().item()


def prf_binary(logits: torch.Tensor, y: torch.Tensor):
    """
    Simple precision/recall/F1 for class index 1 (Dys).
    """
    preds = logits.argmax(dim=-1)
    tp = ((preds == 1) & (y == 1)).sum().item()
    fp = ((preds == 1) & (y == 0)).sum().item()
    fn = ((preds == 0) & (y == 1)).sum().item()

    precision = tp / (tp + fp + 1e-8)
    recall    = tp / (tp + fn + 1e-8)
    f1        = 2 * precision * recall / (precision + recall + 1e-8)
    return precision, recall, f1


def make_loaders(data_root: str):
    train_ds = AudioFolderDataset(os.path.join(data_root, "train"))
    val_ds   = AudioFolderDataset(os.path.join(data_root, "val"))
    test_ds  = AudioFolderDataset(os.path.join(data_root, "test"))

    train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True,
                              num_workers=NUM_WORKERS, collate_fn=collate_batch, pin_memory=True)
    val_loader   = DataLoader(val_ds, batch_size=BATCH_SIZE, shuffle=False,
                              num_workers=NUM_WORKERS, collate_fn=collate_batch, pin_memory=True)
    test_loader  = DataLoader(test_ds, batch_size=BATCH_SIZE, shuffle=False,
                              num_workers=NUM_WORKERS, collate_fn=collate_batch, pin_memory=True)
    return train_loader, val_loader, test_loader


def run_epoch(model, loader, optimizer=None, criterion=None):
    is_train = optimizer is not None
    model.train(is_train)

    total_loss, total_acc, total_n = 0.0, 0.0, 0
    for waves, lengths, labels, _ in loader:
        waves, lengths, labels = waves.to(DEVICE), lengths.to(DEVICE), labels.to(DEVICE)

        logits = model(waves, lengths)
        loss = criterion(logits, labels)

        if is_train:
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()

        bs = labels.size(0)
        total_loss += loss.item() * bs
        total_acc  += accuracy_from_logits(logits.detach(), labels) * bs
        total_n    += bs

    return total_loss / max(1, total_n), total_acc / max(1, total_n)


@torch.no_grad()
def evaluate(model, loader, criterion):
    model.eval()
    total_loss, total_acc, total_n = 0.0, 0.0, 0
    all_logits, all_labels = [], []
    for waves, lengths, labels, _ in loader:
        waves, lengths, labels = waves.to(DEVICE), lengths.to(DEVICE), labels.to(DEVICE)
        logits = model(waves, lengths)
        loss = criterion(logits, labels)

        bs = labels.size(0)
        total_loss += loss.item() * bs
        total_acc  += accuracy_from_logits(logits, labels) * bs
        total_n    += bs
        all_logits.append(logits.cpu())
        all_labels.append(labels.cpu())

    if total_n == 0:
        return float("nan"), float("nan"), (float("nan"), float("nan"), float("nan"))

    all_logits = torch.cat(all_logits, dim=0) if all_logits else torch.empty(0, 2)
    all_labels = torch.cat(all_labels, dim=0) if all_labels else torch.empty(0, dtype=torch.long)
    p, r, f1 = prf_binary(all_logits, all_labels)
    return total_loss / total_n, total_acc / total_n, (p, r, f1)


def load_wav_mono_resample(path: str, target_sr: int = SR) -> torch.Tensor:
    wav, sr = torchaudio.load(path)
    if wav.shape[0] > 1:
        wav = wav.mean(dim=0, keepdim=True)
    if sr != target_sr:
        wav = torchaudio.transforms.Resample(sr, target_sr)(wav)
    return wav.squeeze(0)  # (T,)


@torch.no_grad()
def infer_one(model: AudioTransformerEncoder, wav_path: str):
    model.eval()
    w = load_wav_mono_resample(wav_path, SR)  # (T,)
    waves = w.unsqueeze(0).to(DEVICE)         # (1, T)
    lengths = torch.tensor([w.shape[0]], device=DEVICE)
    feats, logits = model(waves, lengths, return_features=True)
    prob = logits.softmax(dim=-1).squeeze(0).cpu()
    pred_idx = int(prob.argmax().item())
    pred_label = CLASSES[pred_idx]
    return feats.squeeze(0).cpu(), pred_label, prob


# ============================
# Main (no argparse)
# ============================
def main():
    if not os.path.isdir(DATA_ROOT):
        raise FileNotFoundError(
            f"DATA_ROOT '{DATA_ROOT}' not found. "
            f"Expected subfolders train/ val/ test/ each with {CLASSES}."
        )
    for split in ["train", "val", "test"]:
        for cls in CLASSES:
            expect_dir = os.path.join(DATA_ROOT, split, cls)
            if not os.path.isdir(expect_dir):
                print(f"Warning: missing {expect_dir}")

    print(f"Using device: {DEVICE}")
    train_loader, val_loader, test_loader = make_loaders(DATA_ROOT)

    model = AudioTransformerEncoder(
        d_model=D_MODEL, nhead=NHEAD, num_layers=NUM_LAYERS,
        dim_ff=DIM_FF, dropout=DROPOUT,
        patch_size=PATCH_SIZE, patch_stride=PATCH_STRIDE,
        num_classes=2
    ).to(DEVICE)

    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=LR)

    best_val_acc = -1.0
    best_state = None

    for epoch in range(1, EPOCHS + 1):
        tr_loss, tr_acc = run_epoch(model, train_loader, optimizer, criterion)
        va_loss, va_acc, (p, r, f1) = evaluate(model, val_loader, criterion)
        print(f"Epoch {epoch:02d} | train loss {tr_loss:.4f} acc {tr_acc:.4f} "
              f"| val loss {va_loss:.4f} acc {va_acc:.4f} | val P/R/F1 (Dys): {p:.3f}/{r:.3f}/{f1:.3f}")

        if va_acc > best_val_acc:
            best_val_acc = va_acc
            best_state = {k: v.cpu() for k, v in model.state_dict().items()}

    if best_state is not None:
        model.load_state_dict(best_state)
        torch.save(model.state_dict(), SAVE_PATH)
        print(f"Saved best model (val acc {best_val_acc:.4f}) to {SAVE_PATH}")

    # Final test
    te_loss, te_acc, (tp, tr, tf1) = evaluate(model, test_loader, criterion)
    print(f"TEST | loss {te_loss:.4f} acc {te_acc:.4f} | P/R/F1 (Dys): {tp:.3f}/{tr:.3f}/{tf1:.3f}")

    # Optional quick inference
    if INFER_WAV is not None and os.path.isfile(INFER_WAV):
        feats, pred_label, prob = infer_one(model, INFER_WAV)
        print(f"[INFER] {INFER_WAV} -> {pred_label} | prob={prob.tolist()} | feature_dim={tuple(feats.shape)}")
    else:
        if INFER_WAV:
            print(f"[INFER] File not found: {INFER_WAV}")


if __name__ == "__main__":
    main()