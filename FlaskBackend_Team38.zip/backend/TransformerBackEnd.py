# TransformerBackEnd.py — Transformer inference backend (drop-in replacement)
from flask import Flask, request, jsonify
from flask_cors import CORS
import torch, torchaudio, tempfile, os
from Training import AudioTransformerEncoder

app = Flask(__name__)
CORS(app, resources={
    r"/*": {
        "origins": [
            "http://localhost:3000",
            "http://127.0.0.1:3000",
            "http://localhost:5173",
            "http://127.0.0.1:5173",
        ]
    }
})

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
model = AudioTransformerEncoder(
    d_model=128, nhead=4, num_layers=4, dim_ff=256, dropout=0.1,
    patch_size=400, patch_stride=200, num_classes=2
).to(DEVICE)
model.load_state_dict(torch.load('audio_transformer_best.pth', map_location=DEVICE))
model.eval()

def load_wav_mono_resample(path, target_sr=44100):
    wav, sr = torchaudio.load(path)
    if wav.shape[0] > 1:
        wav = wav.mean(dim=0, keepdim=True)
    if sr != target_sr:
        wav = torchaudio.transforms.Resample(sr, target_sr)(wav)
    return wav.squeeze(0)

@app.route('/predict', methods=['POST', 'OPTIONS'])
def predict():
    if request.method == 'OPTIONS':
        return ('', 200)

    if 'file' not in request.files:
        return jsonify({"ok": False, "error": "No file part"}), 400
    f = request.files['file']
    if not f.filename.lower().endswith('.wav'):
        return jsonify({"ok": False, "error": "Only .wav allowed"}), 400

    with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as tmp:
        f.save(tmp.name)
        temp_path = tmp.name
    try:
        w = load_wav_mono_resample(temp_path).unsqueeze(0).to(DEVICE)  # (1, T)
        lengths = torch.tensor([w.shape[1]], device=DEVICE)
        with torch.no_grad():
            logits = model(w, lengths)
            probs = torch.softmax(logits, dim=-1).cpu().numpy()[0]
            pred_idx = int(probs.argmax())
            pred_label = ["Normal", "Dysarthria"][pred_idx]
            pred_score = round(float(probs[pred_idx]) * 100, 2)
        return jsonify({"ok": True, "prediction": pred_label, "score": pred_score}), 200

    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500
    finally:
        try:
            os.remove(temp_path)
        except Exception:
            pass

@app.route('/predict-batch', methods=['POST', 'OPTIONS'])
def predict_batch():
    if request.method == 'OPTIONS':
        return ('', 200)

    files = request.files.getlist('files')
    if not files:
        return jsonify({"ok": False, "error": "No files provided (use 'files' form field)."}), 400

    out = []
    for f in files:
        name = f.filename or "unnamed.wav"
        if not name.lower().endswith('.wav'):
            out.append({"name": name, "error": "Only .wav allowed"})
            continue
        temp_path = None
        try:
            with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as tmp:
                f.save(tmp.name)
                temp_path = tmp.name
            w = load_wav_mono_resample(temp_path).unsqueeze(0).to(DEVICE)
            lengths = torch.tensor([w.shape[1]], device=DEVICE)
            with torch.no_grad():
                logits = model(w, lengths)
                probs = torch.softmax(logits, dim=-1).cpu().numpy()[0]
                pred_idx = int(probs.argmax())
                pred_label = ["Normal", "Dysarthria"][pred_idx]
                pred_score = round(float(probs[pred_idx]) * 100, 2)
            out.append({"name": name, "prediction": pred_label, "score": pred_score})

        except Exception as e:
            out.append({"name": name, "error": str(e)})
        finally:
            if temp_path:
                try:
                    os.remove(temp_path)
                except Exception:
                    pass
        print(out)
    return jsonify({"ok": True, "results": out}), 200

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=True, use_reloader=False)
