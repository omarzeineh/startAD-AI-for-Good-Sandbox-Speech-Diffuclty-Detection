import os, time, random
from pathlib import Path
from typing import List, Tuple

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torch.nn.utils.rnn import pad_sequence, pack_padded_sequence, pad_packed_sequence

import matplotlib
matplotlib.use("Agg")  # headless
import matplotlib.pyplot as plt

try:
    import torchaudio
    from torchaudio import transforms as T
except Exception as e:
    raise RuntimeError("Please install torchaudio: pip install torchaudio") from e


DATA_ROOT = r"D:\unistuff\2025-2026\Fall2025-2026\cohort\SmallSplit"
OUT_DIR   = r"D:\unistuff\pycharm\pythonProject\Cohort\GRU-mel"

# Core runtime
DEVICE       = "cuda"
SEED         = 42
NUM_WORKERS  = 0
BATCH_SIZE   = 8
EPOCHS       = 25
PATIENCE     = 5
CLASS_WEIGHT = False
MAX_TRAIN_BATCHES = None

# Audio / features
SAMPLE_RATE = 44100
SPEED_MODE  = True

if SPEED_MODE:
    N_MELS      = 40
    N_FFT       = 1024
    HOP_LENGTH  = 1024
    GRU_HIDDEN  = 96
    GRU_LAYERS  = 1
else:
    N_MELS      = 64
    N_FFT       = 1024
    HOP_LENGTH  = 512
    GRU_HIDDEN  = 128
    GRU_LAYERS  = 2

FMIN, FMAX  = 20, 8000
DROPOUT     = 0.3

LR           = 2e-3
WEIGHT_DECAY = 1e-4


CLASS_TO_IDX = {"normal": 0, "dysarthria": 1}
IDX_TO_CLASS = {v: k for k, v in CLASS_TO_IDX.items()}

def set_seed(seed=42):
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

def format_duration(seconds: float) -> str:
    seconds = int(round(seconds))
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    return f"{h:02d}:{m:02d}:{s:02d}" if h > 0 else f"{m:02d}:{s:02d}"

def announce(stage: str, out_dir: str):
    """Print and persist current stage so you always know where training is."""
    msg = f"[{time.strftime('%H:%M:%S')}] {stage}"
    print(msg)
    try:
        Path(out_dir).mkdir(parents=True, exist_ok=True)
        with open(Path(out_dir) / "status.txt", "a", encoding="utf-8") as f:
            f.write(msg + "\n")
    except Exception:
        pass


def list_audio_files(split_root: str) -> List[Tuple[str, int]]:
    """
    Finds WAVs under folders named 'Normal' and 'Dysarthria' (case-insensitive).
    Recursively searches *.wav files inside those class folders.
    """
    root = Path(split_root)
    if not root.exists():
        raise RuntimeError(f"Split path does not exist: {root}")

    items: List[Tuple[str, int]] = []
    for p in root.iterdir():
        if not p.is_dir():
            continue
        name = p.name.lower()
        if name.startswith("normal"):
            label = 0
        elif name.startswith("dysarthria"):
            label = 1
        else:
            continue
        for ext in ("*.wav", "*.WAV"):
            for f in p.rglob(ext):
                if f.is_file():
                    items.append((str(f), label))

    n_norm = sum(1 for _, y in items if y == 0)
    n_dys  = sum(1 for _, y in items if y == 1)
    if not items:
        raise RuntimeError(
            f"No WAV files found under {root}.\nExpected:\n"
            f"{root}/Normal/*.wav\n{root}/Dysarthria/*.wav"
        )
    print(f"[DATA] {root} -> {n_norm} Normal, {n_dys} Dysarthria files")
    return items


class AudioDataset(Dataset):
    """
    Returns (wav, label, length):
      wav: (1, S) float32 in [-1,1], mono
      label: long
      length: long (#samples)
    Resamples to SAMPLE_RATE; keeps variable length (no hard trim).
    """
    def __init__(self, split_root: str, target_sr: int = SAMPLE_RATE):
        super().__init__()
        self.items = list_audio_files(split_root)
        self.target_sr = target_sr
        self._resampler_cache: dict[int, T.Resample] = {}

    def __len__(self):
        return len(self.items)

    def _resample_if_needed(self, wav: torch.Tensor, sr: int) -> torch.Tensor:
        if sr == self.target_sr:
            return wav
        if sr not in self._resampler_cache:
            self._resampler_cache[sr] = T.Resample(orig_freq=sr, new_freq=self.target_sr)
        return self._resampler_cache[sr](wav)

    def __getitem__(self, idx: int):
        path, y = self.items[idx]
        wav, sr = torchaudio.load(path)
        if wav.shape[0] > 1:
            wav = wav.mean(dim=0, keepdim=True)
        wav = self._resample_if_needed(wav, sr)
        length = torch.tensor(wav.shape[1], dtype=torch.long)
        return wav, torch.tensor(y, dtype=torch.long), length


def collate_variable(batch):
    """
    Pads to the longest clip in the batch, keeping true lengths.
    Returns:
      wav_pad: (B, 1, Tmax)
      y:       (B,)
      lengths: (B,)
    """
    wavs, ys, lens = zip(*batch)
    wavs_1d = [w.squeeze(0) for w in wavs]
    padded = pad_sequence(wavs_1d, batch_first=True)
    padded = padded.unsqueeze(1)
    return padded, torch.stack(ys), torch.stack(lens)


class LogMel(nn.Module):
    """
    (B,1,T) -> (B, N_MELS, Tm) in dB; per-sample z-score over time.
    """
    def __init__(self):
        super().__init__()
        self.hop_length = HOP_LENGTH
        self.melspec = T.MelSpectrogram(
            sample_rate=SAMPLE_RATE,
            n_fft=N_FFT,
            hop_length=HOP_LENGTH,
            n_mels=N_MELS,
            f_min=FMIN,
            f_max=FMAX,
            power=2.0,
            center=True,
            pad_mode="reflect",
            norm="slaney",
            mel_scale="htk",
        )
        self.to_db = T.AmplitudeToDB(stype="power")

    def forward(self, wav: torch.Tensor) -> torch.Tensor:
        x = self.melspec(wav.squeeze(1))
        x = self.to_db(x)
        mean = x.mean(dim=2, keepdim=True)
        std  = x.std(dim=2, keepdim=True).clamp_min(1e-6)
        x = (x - mean) / std
        return x


class GRUFeat(nn.Module):
    """
    wav (B,1,T) -> logmel (B,F,Tm) -> pack -> BiGRU -> mean-pool -> (B,H*)
    """
    def __init__(self):
        super().__init__()
        self.logmel = LogMel()
        self.rnn = nn.GRU(
            input_size=N_MELS,
            hidden_size=GRU_HIDDEN,
            num_layers=GRU_LAYERS,
            bidirectional=True,
            batch_first=True,
            dropout=DROPOUT if GRU_LAYERS > 1 else 0.0,
        )
        self.out_dim = GRU_HIDDEN * 2
        self.drop = nn.Dropout(DROPOUT)

    def forward(self, wav: torch.Tensor, lengths: torch.Tensor) -> torch.Tensor:
        x = self.logmel(wav)
        x = x.permute(0, 2, 1)
        frame_len = (lengths // self.logmel.hop_length).clamp_min(1).cpu()
        packed = pack_padded_sequence(x, frame_len, batch_first=True, enforce_sorted=False)
        out, _ = self.rnn(packed)
        out, _ = pad_packed_sequence(out, batch_first=True)
        emb = out.mean(dim=1)
        return self.drop(emb)


class DysarthriaGRU(nn.Module):
    def __init__(self):
        super().__init__()
        self.feat = GRUFeat()
        self.fc = nn.Sequential(
            nn.Linear(self.feat.out_dim, 192 if SPEED_MODE else 256),
            nn.ReLU(inplace=True),
            nn.Dropout(DROPOUT),
            nn.Linear(192 if SPEED_MODE else 256, 2),
        )
        self.softmax = nn.Softmax(dim=1)

    def forward(self, wav, lengths):
        z = self.feat(wav, lengths)
        return self.fc(z)

    @torch.no_grad()
    def predict(self, wav, lengths):
        return self.softmax(self.forward(wav, lengths))


def accuracy(logits, y):
    return (logits.argmax(1) == y).float().mean().item()

@torch.no_grad()
def evaluate(model, dl, dev):
    model.eval()
    ce = nn.CrossEntropyLoss()
    L = A = N = 0
    for wav, y, l in dl:
        wav, y, l = wav.to(dev), y.to(dev), l.to(dev)
        out = model(wav, l)
        loss = ce(out, y)
        b = y.size(0)
        L += loss.item() * b
        A += accuracy(out, y) * b
        N += b
    return L / max(1, N), A / max(1, N)


def collect_scores(model, dl, dev):
    """
    Collects y_true and y_score (probability for class 'dysarthria'=1) and y_pred.
    """
    model.eval()
    y_true, y_score, y_pred = [], [], []
    with torch.no_grad():
        for wav, y, l in dl:
            wav, y, l = wav.to(dev), y.to(dev), l.to(dev)
            probs = model.predict(wav, l)
            score1 = probs[:, 1]
            pred = probs.argmax(1)
            y_true.append(y.cpu()); y_score.append(score1.cpu()); y_pred.append(pred.cpu())
    y_true = torch.cat(y_true).numpy()
    y_score = torch.cat(y_score).numpy()
    y_pred = torch.cat(y_pred).numpy()
    return y_true, y_score, y_pred


def plot_training_curves(history, out_png):
    epochs = history["epoch"]
    plt.figure(figsize=(7,5))
    plt.plot(epochs, history["train_loss"], label="Train loss")
    plt.plot(epochs, history["val_loss"],   label="Val loss")
    plt.xlabel("Epoch"); plt.ylabel("Loss"); plt.title("Training & Validation Loss")
    plt.legend(); plt.tight_layout(); plt.savefig(out_png, dpi=150); plt.close()


def plot_confusion_matrix(y_true, y_pred, out_png, labels=("Normal","Dysarthria")):
    import numpy as np
    cm = np.zeros((2,2), dtype=int)
    for t, p in zip(y_true, y_pred):
        cm[int(t), int(p)] += 1

    plt.figure(figsize=(4.6,4.2))
    plt.imshow(cm, interpolation="nearest")
    plt.xticks([0,1], labels); plt.yticks([0,1], labels)
    plt.xlabel("Predicted"); plt.ylabel("True"); plt.title("Confusion Matrix")
    for i in range(2):
        for j in range(2):
            plt.text(j, i, str(cm[i, j]), ha="center", va="center")
    plt.tight_layout(); plt.savefig(out_png, dpi=150); plt.close()


def plot_roc(y_true, y_score, out_png):
    import numpy as np
    order = np.argsort(-y_score)
    y_true = y_true[order]; y_score = y_score[order]
    P = (y_true == 1).sum(); N = (y_true == 0).sum()
    if P == 0 or N == 0:
        fpr = np.array([0,1]); tpr = np.array([0,1]) if P == 0 else np.array([0,0]); auc = float("nan")
    else:
        tps = np.cumsum(y_true == 1); fps = np.cumsum(y_true == 0)
        tpr = tps / P; fpr = fps / N
        tpr = np.concatenate(([0.0], tpr)); fpr = np.concatenate(([0.0], fpr))
        auc = np.trapz(tpr, fpr)

    plt.figure(figsize=(5.5,5))
    plt.plot(fpr, tpr, label=f"ROC (AUC={auc:.3f})")
    plt.plot([0,1], [0,1], linestyle="--")
    plt.xlabel("False Positive Rate"); plt.ylabel("True Positive Rate")
    plt.title("ROC Curve (Dysarthria=positive)")
    plt.legend(loc="lower right"); plt.tight_layout(); plt.savefig(out_png, dpi=150); plt.close()
    return auc


def plot_pr(y_true, y_score, out_png):
    """
    Precision-Recall curve + AUC(PR) without sklearn.
    Positive class = Dysarthria (1).
    """
    import numpy as np
    order = np.argsort(-y_score)
    y_true = y_true[order]
    y_score = y_score[order]

    P = (y_true == 1).sum()
    if P == 0:
        recall = np.array([0,1]); precision = np.array([1,1]); auc_pr = float("nan")
    else:
        tps = np.cumsum(y_true == 1)
        fps = np.cumsum(y_true == 0)
        precision = tps / np.maximum(1, tps + fps)
        recall = tps / P
        precision = np.concatenate(([1.0], precision))
        recall = np.concatenate(([0.0], recall))
        auc_pr = np.trapz(precision, recall)

    plt.figure(figsize=(5.5,5))
    plt.plot(recall, precision, label=f"PR (AUC={auc_pr:.3f})")
    plt.xlabel("Recall"); plt.ylabel("Precision")
    plt.title("Precision–Recall (Dysarthria=positive)")
    plt.legend(loc="lower left"); plt.tight_layout(); plt.savefig(out_png, dpi=150); plt.close()
    return auc_pr


def main():
    set_seed(SEED)
    dev = torch.device("cuda" if (DEVICE == "cuda" and torch.cuda.is_available()) else "cpu")
    Path(OUT_DIR).mkdir(parents=True, exist_ok=True)
    announce(f"START | device={dev} SPEED_MODE={SPEED_MODE} "
             f"n_mels={N_MELS} hop={HOP_LENGTH} hidden={GRU_HIDDEN} layers={GRU_LAYERS}", OUT_DIR)

    def loader(split: str):
        split_path = os.path.join(DATA_ROOT, split)
        ds = AudioDataset(split_path, SAMPLE_RATE)
        return DataLoader(
            ds,
            batch_size=BATCH_SIZE,
            shuffle=(split == "train"),
            num_workers=NUM_WORKERS,
            pin_memory=True,
            collate_fn=collate_variable,
        )

    announce("Loading datasets...", OUT_DIR)
    train_dl, val_dl, test_dl = loader("train"), loader("val"), loader("test")

    model = DysarthriaGRU().to(dev)
    print(f"Params: {sum(p.numel() for p in model.parameters() if p.requires_grad):,}")

    if CLASS_WEIGHT:
        counts = torch.zeros(2)
        for _, y, _ in train_dl.dataset:
            counts[y.item()] += 1
        w = 1.0 / counts.clamp_min(1.0)
        w = (w / w.sum()) * 2.0
        print(f"Using class weights: {w.tolist()}")
        ce = nn.CrossEntropyLoss(weight=w.to(dev))
    else:
        ce = nn.CrossEntropyLoss()

    opt = optim.AdamW(model.parameters(), lr=LR, weight_decay=WEIGHT_DECAY)
    sched = optim.lr_scheduler.ReduceLROnPlateau(opt, mode="min", patience=2, factor=0.5)

    best = float("inf")
    noimp = 0
    ckpt = Path(OUT_DIR) / "best_gru.pt"

    history = {"epoch": [], "train_loss": [], "val_loss": [], "val_acc": []}

    train_start = time.time()
    announce("Training started", OUT_DIR)

    for ep in range(1, EPOCHS + 1):
        epoch_start = time.time()
        announce(f"Epoch {ep}/{EPOCHS} - training", OUT_DIR)

        model.train()
        L = A = N = 0
        for b_idx, (wav, y, l) in enumerate(train_dl, start=1):
            wav, y, l = wav.to(dev), y.to(dev), l.to(dev)
            opt.zero_grad(set_to_none=True)
            out = model(wav, l)
            loss = ce(out, y)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            b = y.size(0)
            L += loss.item() * b
            A += accuracy(out, y) * b
            N += b
            if MAX_TRAIN_BATCHES is not None and b_idx >= MAX_TRAIN_BATCHES:
                break

        trL = L / max(1, N)

        announce(f"Epoch {ep}/{EPOCHS} - validating", OUT_DIR)
        vL, vA = evaluate(model, val_dl, dev)
        sched.step(vL)

        history["epoch"].append(ep)
        history["train_loss"].append(trL)
        history["val_loss"].append(vL)
        history["val_acc"].append(vA)

        epoch_secs = time.time() - epoch_start
        elapsed_secs = time.time() - train_start
        remaining_epochs = EPOCHS - ep
        eta_secs = remaining_epochs * epoch_secs

        print(
            f"[{ep:03d}/{EPOCHS}] "
            f"epoch={format_duration(epoch_secs)}  "
            f"elapsed={format_duration(elapsed_secs)}  "
            f"eta~={format_duration(eta_secs)}  "
            f"trainL={trL:.4f}  valL={vL:.4f}  valA={vA:.3f}"
        )

        if vL < best - 1e-5:
            best = vL
            noimp = 0
            torch.save(model.state_dict(), ckpt)
            announce(f"Epoch {ep} - new best saved to {ckpt}", OUT_DIR)
        else:
            noimp += 1
            if noimp >= PATIENCE:
                announce("Early stopping triggered", OUT_DIR)
                break

    announce("Loading best checkpoint", OUT_DIR)
    model.load_state_dict(torch.load(ckpt, map_location=dev))

    announce("Plotting training curves", OUT_DIR)
    training_curve_png = str(Path(OUT_DIR) / "training_curves.png")
    plot_training_curves(history, training_curve_png)
    print(f"Saved training curve to {training_curve_png}")

    announce("Evaluating on test set", OUT_DIR)
    tL, tA = evaluate(model, test_dl, dev)
    print(f"Test loss={tL:.4f}  acc={tA:.3f}")

    announce("Collecting scores for ROC/PR/CM", OUT_DIR)
    y_true, y_score, y_pred = collect_scores(model, test_dl, dev)

    roc_png = str(Path(OUT_DIR) / "roc_curve.png")
    auc = plot_roc(y_true, y_score, roc_png)
    print(f"Saved ROC curve to {roc_png} (AUC={auc:.3f})")

    pr_png = str(Path(OUT_DIR) / "precision_recall.png")
    auc_pr = plot_pr(y_true, y_score, pr_png)
    print(f"Saved Precision–Recall curve to {pr_png} (AUC={auc_pr:.3f})")

    cm_png = str(Path(OUT_DIR) / "confusion_matrix.png")
    plot_confusion_matrix(y_true, y_pred, cm_png, labels=("Normal","Dysarthria"))
    print(f"Saved confusion matrix to {cm_png}")

    announce("DONE", OUT_DIR)

    model.eval()
    with torch.no_grad():
        for wav, y, l in test_dl:
            wav, l = wav.to(dev), l.to(dev)
            probs = model.predict(wav[:2], l[:2])
            print("Example softmax probabilities:\n", probs.cpu())
            break


if __name__ == "__main__":
    main()
