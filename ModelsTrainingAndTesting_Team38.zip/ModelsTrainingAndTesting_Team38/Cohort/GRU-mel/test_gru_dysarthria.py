import os, time, random, csv
from pathlib import Path
from typing import List, Tuple

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from torch.nn.utils.rnn import pad_sequence, pack_padded_sequence, pad_packed_sequence

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

try:
    import torchaudio
    from torchaudio import transforms as T
except Exception as e:
    raise RuntimeError("Please install torchaudio: pip install torchaudio") from e



TEST_ROOT = r"D:\unistuff\2025-2026\Fall2025-2026\cohort\SmallSplit"
CKPT_PATH = r"D:\unistuff\pycharm\pythonProject\Cohort\GRU-mel\best_gru.pt"
OUT_DIR   = r"D:\unistuff\pycharm\pythonProject\Cohort\GRU-mel\eval_small"

SPEED_MODE  = True
SAMPLE_RATE = 44100

# Runtime
DEVICE      = "cuda"
BATCH_SIZE  = 16
NUM_WORKERS = 0
SEED        = 42


if SPEED_MODE:
    N_MELS      = 40
    N_FFT       = 1024
    HOP_LENGTH  = 1024
    GRU_HIDDEN  = 96
    GRU_LAYERS  = 1
    FC_HIDDEN   = 192
else:
    N_MELS      = 64
    N_FFT       = 1024
    HOP_LENGTH  = 512
    GRU_HIDDEN  = 128
    GRU_LAYERS  = 2
    FC_HIDDEN   = 256

FMIN, FMAX  = 20, 8000
DROPOUT     = 0.3

CLASS_TO_IDX = {"normal": 0, "dysarthria": 1}
IDX_TO_CLASS = {v: k for k, v in CLASS_TO_IDX.items()}


def set_seed(seed=42):
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def format_duration(seconds: float) -> str:
    seconds = int(round(seconds))
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    return f"{h:02d}:{m:02d}:{s:02d}" if h > 0 else f"{m:02d}:{s:02d}"


def announce(stage: str, out_dir: str):
    msg = f"[{time.strftime('%H:%M:%S')}] {stage}"
    print(msg)
    try:
        Path(out_dir).mkdir(parents=True, exist_ok=True)
        with open(Path(out_dir) / "status_eval.txt", "a", encoding="utf-8") as f:
            f.write(msg + "\n")
    except Exception:
        pass


def list_audio_files_any_test_root(root_path: str) -> List[Tuple[str, int]]:
    root = Path(root_path)
    if not root.exists():
        raise RuntimeError(f"Test path does not exist: {root}")

    def scan_class_dir(base: Path) -> List[Tuple[str, int]]:
        items: List[Tuple[str, int]] = []
        for p in base.iterdir():
            if not p.is_dir():
                continue
            name = p.name.lower()
            if name.startswith("normal"):
                label = 0
            elif name.startswith("dysarthria"):
                label = 1
            else:
                continue
            for ext in ("*.wav", "*.WAV"):
                for f in p.rglob(ext):
                    if f.is_file():
                        items.append((str(f), label))
        return items

    items = scan_class_dir(root)
    if not items and (root / "test").exists():
        items = scan_class_dir(root / "test")

    if not items:
        raise RuntimeError(
            f"No WAVs found under {root}.\n"
            f"Expect either:\n - {root}/Normal, {root}/Dysarthria\n"
            f"or\n - {root}/test/Normal, {root}/test/Dysarthria"
        )

    n_norm = sum(1 for _, y in items if y == 0)
    n_dys  = sum(1 for _, y in items if y == 1)
    print(f"[DATA] {root} -> {n_norm} Normal, {n_dys} Dysarthria files")
    return items


class AudioTestDataset(Dataset):
    def __init__(self, test_root: str, target_sr: int = SAMPLE_RATE):
        super().__init__()
        self.items = list_audio_files_any_test_root(test_root)
        self.target_sr = target_sr
        self._resampler_cache: dict[int, T.Resample] = {}

    def __len__(self): return len(self.items)

    def _resample_if_needed(self, wav: torch.Tensor, sr: int) -> torch.Tensor:
        if sr == self.target_sr:
            return wav
        if sr not in self._resampler_cache:
            self._resampler_cache[sr] = T.Resample(orig_freq=sr, new_freq=self.target_sr)
        return self._resampler_cache[sr](wav)

    def __getitem__(self, i: int):
        path, y = self.items[i]
        wav, sr = torchaudio.load(path)
        if wav.shape[0] > 1:
            wav = wav.mean(dim=0, keepdim=True)
        wav = self._resample_if_needed(wav, sr)
        length = torch.tensor(wav.shape[1], dtype=torch.long)
        return wav, torch.tensor(y, dtype=torch.long), length, path


def collate_variable(batch):
    wavs, ys, lens, paths = zip(*batch)
    wavs_1d = [w.squeeze(0) for w in wavs]
    padded = pad_sequence(wavs_1d, batch_first=True).unsqueeze(1)
    return padded, torch.stack(ys), torch.stack(lens), list(paths)


class LogMel(nn.Module):
    def __init__(self):
        super().__init__()
        self.hop_length = HOP_LENGTH
        self.melspec = T.MelSpectrogram(
            sample_rate=SAMPLE_RATE,
            n_fft=N_FFT,
            hop_length=HOP_LENGTH,
            n_mels=N_MELS,
            f_min=FMIN,
            f_max=FMAX,
            power=2.0,
            center=True,
            pad_mode="reflect",
            norm="slaney",
            mel_scale="htk",
        )
        self.to_db = T.AmplitudeToDB(stype="power")
    def forward(self, wav: torch.Tensor) -> torch.Tensor:
        x = self.melspec(wav.squeeze(1))
        x = self.to_db(x)
        m = x.mean(dim=2, keepdim=True); s = x.std(dim=2, keepdim=True).clamp_min(1e-6)
        return (x - m) / s


class GRUFeat(nn.Module):
    def __init__(self):
        super().__init__()
        self.logmel = LogMel()
        self.rnn = nn.GRU(
            input_size=N_MELS,
            hidden_size=GRU_HIDDEN,
            num_layers=GRU_LAYERS,
            bidirectional=True,
            batch_first=True,
            dropout=0.0 if GRU_LAYERS <= 1 else DROPOUT,
        )
        self.out_dim = GRU_HIDDEN * 2
        self.drop = nn.Dropout(DROPOUT)
    def forward(self, wav, lengths):
        x = self.logmel(wav).permute(0, 2, 1)  # (B,T,F)
        frame_len = (lengths // self.logmel.hop_length).clamp_min(1).cpu()
        packed = pack_padded_sequence(x, frame_len, batch_first=True, enforce_sorted=False)
        out, _ = self.rnn(packed)
        out, _ = pad_packed_sequence(out, batch_first=True)
        return self.drop(out.mean(1))


class DysarthriaGRU(nn.Module):
    def __init__(self):
        super().__init__()
        self.feat = GRUFeat()
        self.fc = nn.Sequential(
            nn.Linear(self.feat.out_dim, FC_HIDDEN),
            nn.ReLU(inplace=True),
            nn.Dropout(DROPOUT),
            nn.Linear(FC_HIDDEN, 2),
        )
        self.softmax = nn.Softmax(dim=1)
    def forward(self, wav, lengths):
        z = self.feat(wav, lengths)
        return self.fc(z)
    @torch.no_grad()
    def predict(self, wav, lengths):
        return self.softmax(self.forward(wav, lengths))


@torch.no_grad()
def evaluate(model, dl, dev):
    model.eval()
    ce = nn.CrossEntropyLoss()
    L = A = N = 0
    for wav, y, l, _ in dl:
        wav, y, l = wav.to(dev), y.to(dev), l.to(dev)
        out = model(wav, l)
        loss = ce(out, y)
        b = y.size(0)
        L += loss.item() * b
        A += (out.argmax(1) == y).float().sum().item()
        N += b
    return L / max(1, N), A / max(1, N)

@torch.no_grad()
def collect_scores(model, dl, dev):
    model.eval()
    y_true, y_pred, y_score, paths = [], [], [], []
    for wav, y, l, batch_paths in dl:
        wav, y, l = wav.to(dev), y.to(dev), l.to(dev)
        probs = model.predict(wav, l)
        pred = probs.argmax(1)
        score1 = probs[:, 1]
        y_true.append(y.cpu()); y_pred.append(pred.cpu()); y_score.append(score1.cpu()); paths += batch_paths
    y_true = torch.cat(y_true).numpy()
    y_pred = torch.cat(y_pred).numpy()
    y_score = torch.cat(y_score).numpy()
    return y_true, y_pred, y_score, paths

def confusion_from_preds(y_true, y_pred):
    import numpy as np
    cm = np.zeros((2,2), dtype=int)
    for t, p in zip(y_true, y_pred):
        cm[int(t), int(p)] += 1
    return cm

def prf_from_confusion(cm):
    import numpy as np
    TP = cm[1,1]; FP = cm[0,1]; FN = cm[1,0]; TN = cm[0,0]
    def safe_div(a,b): return float(a)/float(b) if b>0 else 0.0
    prec_pos = safe_div(TP, TP+FP)
    rec_pos  = safe_div(TP, TP+FN)
    f1_pos   = safe_div(2*prec_pos*rec_pos, prec_pos+rec_pos) if (prec_pos+rec_pos)>0 else 0.0
    prec_neg = safe_div(TN, TN+FN)
    rec_neg  = safe_div(TN, TN+FP)
    f1_neg   = safe_div(2*prec_neg*rec_neg, prec_neg+rec_neg) if (prec_neg+rec_neg)>0 else 0.0
    return {
        "pos": {"precision":prec_pos, "recall":rec_pos, "f1":f1_pos},
        "neg": {"precision":prec_neg, "recall":rec_neg, "f1":f1_neg},
        "support": {"pos": int(TP+FN), "neg": int(TN+FP)}
    }

def plot_confusion(cm, out_png, labels=("Normal","Dysarthria")):
    import numpy as np
    plt.figure(figsize=(4.6,4.2))
    plt.imshow(cm, interpolation="nearest")
    plt.xticks([0,1], labels); plt.yticks([0,1], labels)
    plt.xlabel("Predicted"); plt.ylabel("True"); plt.title("Confusion Matrix")
    for i in range(2):
        for j in range(2):
            plt.text(j, i, str(cm[i, j]), ha="center", va="center")
    plt.tight_layout(); plt.savefig(out_png, dpi=150); plt.close()

def plot_roc(y_true, y_score, out_png):
    import numpy as np
    order = np.argsort(-y_score)
    y_true = y_true[order]; y_score = y_score[order]
    P = (y_true == 1).sum(); N = (y_true == 0).sum()
    if P == 0 or N == 0:
        fpr = np.array([0,1]); tpr = np.array([0,1]) if P == 0 else np.array([0,0]); auc = float("nan")
    else:
        tps = np.cumsum(y_true == 1); fps = np.cumsum(y_true == 0)
        tpr = tps / P; fpr = fps / N
        tpr = np.concatenate(([0.0], tpr)); fpr = np.concatenate(([0.0], fpr))
        auc = np.trapz(tpr, fpr)
    plt.figure(figsize=(5.5,5))
    plt.plot(fpr, tpr, label=f"ROC (AUC={auc:.3f})")
    plt.plot([0,1], [0,1], linestyle="--")
    plt.xlabel("False Positive Rate"); plt.ylabel("True Positive Rate")
    plt.title("ROC Curve (Dysarthria=positive)")
    plt.legend(loc="lower right"); plt.tight_layout(); plt.savefig(out_png, dpi=150); plt.close()
    return auc

def plot_pr(y_true, y_score, out_png):
    import numpy as np
    order = np.argsort(-y_score)
    y_true = y_true[order]; y_score = y_score[order]
    P = (y_true == 1).sum()
    if P == 0:
        recall = np.array([0,1]); precision = np.array([1,1]); auc_pr = float("nan")
    else:
        tps = np.cumsum(y_true == 1); fps = np.cumsum(y_true == 0)
        precision = tps / np.maximum(1, tps + fps)
        recall = tps / P
        precision = np.concatenate(([1.0], precision))
        recall = np.concatenate(([0.0], recall))
        auc_pr = np.trapz(precision, recall)
    plt.figure(figsize=(5.5,5))
    plt.plot(recall, precision, label=f"PR (AUC={auc_pr:.3f})")
    plt.xlabel("Recall"); plt.ylabel("Precision")
    plt.title("Precision–Recall (Dysarthria=positive)")
    plt.legend(loc="lower left"); plt.tight_layout(); plt.savefig(out_png, dpi=150); plt.close()
    return auc_pr


# ------------------------- Main -----------------------------
def main():
    set_seed(SEED)
    dev = torch.device("cuda" if (DEVICE == "cuda" and torch.cuda.is_available()) else "cpu")
    Path(OUT_DIR).mkdir(parents=True, exist_ok=True)

    announce(f"START EVAL | device={dev} SPEED_MODE={SPEED_MODE} "
             f"n_mels={N_MELS} hop={HOP_LENGTH} hidden={GRU_HIDDEN} layers={GRU_LAYERS}", OUT_DIR)

    # Data
    announce("Loading test dataset...", OUT_DIR)
    test_ds = AudioTestDataset(TEST_ROOT, SAMPLE_RATE)
    test_dl = DataLoader(test_ds, batch_size=BATCH_SIZE, shuffle=False,
                         num_workers=NUM_WORKERS, pin_memory=True, collate_fn=collate_variable)

    # Model
    announce("Building model...", OUT_DIR)
    model = DysarthriaGRU().to(dev)

    if not Path(CKPT_PATH).exists():
        raise FileNotFoundError(f"Checkpoint not found: {CKPT_PATH}")
    announce(f"Loading checkpoint: {CKPT_PATH}", OUT_DIR)
    state = torch.load(CKPT_PATH, map_location=dev)
    model.load_state_dict(state)

    # Quick eval
    announce("Evaluating...", OUT_DIR)
    loss, acc = evaluate(model, test_dl, dev)
    print(f"Test loss={loss:.4f}  acc={acc:.3f}")

    # Collect detailed scores
    announce("Collecting scores...", OUT_DIR)
    y_true, y_pred, y_score, paths = collect_scores(model, test_dl, dev)

    # Confusion + per-class PRF
    cm = confusion_from_preds(y_true, y_pred)
    prf = prf_from_confusion(cm)
    print("Per-class metrics (F1/Precision/Recall):")
    print(f"  Normal     : P={prf['neg']['precision']:.3f}  R={prf['neg']['recall']:.3f}  F1={prf['neg']['f1']:.3f}")
    print(f"  Dysarthria : P={prf['pos']['precision']:.3f}  R={prf['pos']['recall']:.3f}  F1={prf['pos']['f1']:.3f}")

    # Plots
    announce("Plotting ROC/PR/CM...", OUT_DIR)
    roc_png = str(Path(OUT_DIR) / "roc_curve_large.png")
    auc = plot_roc(y_true, y_score, roc_png)
    pr_png = str(Path(OUT_DIR) / "precision_recall_large.png")
    auc_pr = plot_pr(y_true, y_score, pr_png)
    cm_png = str(Path(OUT_DIR) / "confusion_matrix_large.png")
    plot_confusion(cm, cm_png, labels=("Normal","Dysarthria"))

    print(f"Saved: {roc_png} (AUC={auc:.3f}), {pr_png} (AUC_PR={auc_pr:.3f}), {cm_png}")

    # CSV with per-file predictions
    csv_path = str(Path(OUT_DIR) / "predictions_large.csv")
    announce(f"Writing predictions CSV: {csv_path}", OUT_DIR)
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["filepath", "true_label", "pred_label", "prob_normal", "prob_dysarthria"])
    probs0, probs1 = [], []
    with torch.no_grad():
        for wav, y, l, batch_paths in test_dl:
            wav, l = wav.to(dev), l.to(dev)
            p = model.predict(wav, l).cpu().numpy()
            probs0.extend(p[:,0].tolist()); probs1.extend(p[:,1].tolist())

    with open(csv_path, "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        for i in range(len(paths)):
            tl = int(y_true[i]); pl = int(y_pred[i])
            w.writerow([paths[i], IDX_TO_CLASS[tl], IDX_TO_CLASS[pl], f"{probs0[i]:.6f}", f"{probs1[i]:.6f}"])
    print(f"Wrote predictions to {csv_path}")

    announce("DONE", OUT_DIR)


if __name__ == "__main__":
    main()
