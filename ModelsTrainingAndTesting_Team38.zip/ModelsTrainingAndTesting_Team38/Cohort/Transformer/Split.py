from pathlib import Path
import random
import shutil

DATA_ROOT   = r"D:\unistuff\2025-2026\Fall2025-2026\cohort\archive"
CLASS_DIRS  = ["Control", "Dys"]
VAL_RATIO   = 0.1
TEST_RATIO  = 0.1
SEED        = 42
OUTPUT_DIR  = r"D:\unistuff\2025-2026\Fall2025-2026\cohort"
MAKE_DIRS   = True

def list_wavs(class_dir: Path):
    return sorted([p.resolve() for p in class_dir.rglob("*") if p.is_file() and p.suffix.lower()==".wav"])

def split_indices(n, val_ratio, test_ratio):
    idx = list(range(n))
    random.shuffle(idx)
    n_test = int(round(n * test_ratio))
    n_val  = int(round(n * val_ratio))
    test_idx = idx[:n_test]
    val_idx  = idx[n_test:n_test+n_val]
    train_idx = idx[n_test+n_val:]
    return train_idx, val_idx, test_idx

def write_list(rows, out_path: Path):
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w", encoding="utf-8") as f:
        for path, label in rows:
            f.write(f"{path},{label}\n")

def maybe_copy(rows, split_root: Path):
    for split_name, items in rows.items():
        for path, label in items:
            dst = split_root / split_name / label / Path(path).name
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, dst)

def main():
    random.seed(SEED)

    root = Path(DATA_ROOT).expanduser().resolve()
    out  = Path(OUTPUT_DIR).expanduser().resolve()

    data = {}
    for cls in CLASS_DIRS:
        class_path = root / cls
        if not class_path.exists():
            raise SystemExit(f"Missing class folder: {class_path}")
        files = list_wavs(class_path)
        if not files:
            raise SystemExit(f"No .wav files found in: {class_path}")
        data[cls] = files

    splits = {"train": [], "val": [], "test": []}
    for cls in CLASS_DIRS:
        files = data[cls]
        n = len(files)
        train_idx, val_idx, test_idx = split_indices(n, VAL_RATIO, TEST_RATIO)

        train_rows = [(str(files[i]), cls) for i in train_idx]
        val_rows   = [(str(files[i]), cls) for i in val_idx]
        test_rows  = [(str(files[i]), cls) for i in test_idx]

        splits["train"].extend(train_rows)
        splits["val"].extend(val_rows)
        splits["test"].extend(test_rows)

    write_list(splits["train"], out / "train.txt")
    write_list(splits["val"],   out / "val.txt")
    write_list(splits["test"],  out / "test.txt")

    if MAKE_DIRS:
        maybe_copy(splits, out / "split_audio")

    def count_by_label(rows):
        c = {cls: 0 for cls in CLASS_DIRS}
        for _, lbl in rows:
            c[lbl] += 1
        return c

    print("Done.")
    for name in ["train", "val", "test"]:
        counts = count_by_label(splits[name])
        total = sum(counts.values())
        print(f"{name}: {total} files -> " + ", ".join([f"{k}:{v}" for k,v in counts.items()]))

if __name__ == "__main__":
    main()
