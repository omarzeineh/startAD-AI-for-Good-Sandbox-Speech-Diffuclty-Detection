import os
import torch
from Training import AudioTransformerEncoder, D_MODEL, NHEAD, NUM_LAYERS, DIM_FF, DROPOUT, PATCH_SIZE, PATCH_STRIDE, CLASSES, DEVICE, SAVE_PATH
from torch.utils.data import DataLoader
from Training import AudioFolderDataset, collate_batch, make_loaders  # Assuming you have the dataset code in 'dataset.py'
import torchaudio
import torch.nn as nn

def load_model():
    model = AudioTransformerEncoder(
        d_model=D_MODEL, nhead=NHEAD, num_layers=NUM_LAYERS,
        dim_ff=DIM_FF, dropout=DROPOUT,
        patch_size=PATCH_SIZE, patch_stride=PATCH_STRIDE,
        num_classes=len(CLASSES)
    ).to(DEVICE)

    model.load_state_dict(torch.load(SAVE_PATH))
    return model

def evaluate(model, loader, criterion):
    model.eval()
    total_loss, total_acc, total_n = 0.0, 0.0, 0
    all_logits, all_labels = [], []
    for waves, lengths, labels, _ in loader:
        waves, lengths, labels = waves.to(DEVICE), lengths.to(DEVICE), labels.to(DEVICE)
        logits = model(waves, lengths)
        loss = criterion(logits, labels)

        bs = labels.size(0)
        total_loss += loss.item() * bs
        total_acc  += accuracy_from_logits(logits, labels) * bs
        total_n    += bs
        all_logits.append(logits.cpu())
        all_labels.append(labels.cpu())

    if total_n == 0:
        return float("nan"), float("nan"), (float("nan"), float("nan"), float("nan"))

    all_logits = torch.cat(all_logits, dim=0) if all_logits else torch.empty(0, 2)
    all_labels = torch.cat(all_labels, dim=0) if all_labels else torch.empty(0, dtype=torch.long)
    p, r, f1 = prf_binary(all_logits, all_labels)
    return total_loss / total_n, total_acc / total_n, (p, r, f1)

def accuracy_from_logits(logits: torch.Tensor, y: torch.Tensor) -> float:
    preds = logits.argmax(dim=-1)
    return (preds == y).float().mean().item()

def prf_binary(logits: torch.Tensor, y: torch.Tensor):
    preds = logits.argmax(dim=-1)
    tp = ((preds == 1) & (y == 1)).sum().item()
    fp = ((preds == 1) & (y == 0)).sum().item()
    fn = ((preds == 0) & (y == 1)).sum().item()

    precision = tp / (tp + fp + 1e-8)
    recall    = tp / (tp + fn + 1e-8)
    f1        = 2 * precision * recall / (precision + recall + 1e-8)
    return precision, recall, f1

def infer_one(model, wav_path: str):
    model.eval()
    wav, sr = torchaudio.load(wav_path)
    if wav.shape[0] > 1:
        wav = wav.mean(dim=0, keepdim=True)
    wav = torchaudio.transforms.Resample(sr, 44100)(wav)
    wav = wav.unsqueeze(0).to(DEVICE)
    lengths = torch.tensor([wav.shape[1]], device=DEVICE)
    logits = model(wav, lengths)
    prob = logits.softmax(dim=-1).squeeze(0).cpu()
    pred_idx = int(prob.argmax().item())
    pred_label = CLASSES[pred_idx]
    return pred_label, prob

def main():
    model = load_model()
    model.to(DEVICE)

    test_loader = make_loaders(r"D:\unistuff\2025-2026\Fall2025-2026\cohort\SmallSplit")[2]
    criterion = nn.CrossEntropyLoss()

    test_loss, test_acc, (tp, tr, tf1) = evaluate(model, test_loader, criterion)
    print(f"TEST | loss {test_loss:.4f} acc {test_acc:.4f} | P/R/F1 (Dys): {tp:.3f}/{tr:.3f}/{tf1:.3f}")


if __name__ == "__main__":
    main()